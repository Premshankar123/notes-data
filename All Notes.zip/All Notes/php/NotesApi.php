<?php
$server = "localhost";
$user = "root";
$pass = "";
$dbname = "allnotes";
$conn=new Mysqli($server,$user,$pass,$dbname);
if($conn->connect_error){
    die("connection failed".$conn->connect_error);
}
$select="select * from notes";
$query=$conn->query($select);
$i=1;
if($query->num_rows>0){
    echo "[";
    while($row=$query->fetch_assoc()){
         echo json_encode($row);
         if($query->num_rows>$i){
             echo ",";
         }$i++;
    }
    
   echo "]";
}

$conn->close();
?>