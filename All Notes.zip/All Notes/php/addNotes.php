<?php
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "allnotes";
$title=$_POST['title'];
$description=$_POST['description'];
$img=$_POST['image'];
$filename='IMG'.rand().'.jpg';
$imgurl="http://192.168.43.38/php/image/".$filename;
file_put_contents("image/".$filename,base64_decode($img));
// Create connection
$conn = mysqli_connect($servername, $user, $pass, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: ". mysqli_connect_error());
}

$sql = "INSERT INTO notes(title,description,imageurl)
VALUES('$title','$description', '$imgurl')";

if (mysqli_query($conn, $sql)) {
  echo "Notes Added successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>