<?php
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "signup";
$name=$_POST["names"];
$mobile=$_POST["mobiles"];
$email=$_POST["emails"];
$password=$_POST["passs"];

// Create connection
$conn = new mysqli($servername, $user, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO signupdata(name,mobile,email,password) VALUES('$name','$mobile','$email','$password')";

if ($conn->query($sql) === TRUE) {
  echo "Sign Up successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>