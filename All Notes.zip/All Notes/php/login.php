<?php
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "signup";
$email=$_POST["email"];
$password=$_POST["pass"];

// Create connection
$conn = new mysqli($servername, $user, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM signupdata WHERE email='$email' AND password='$password' ";
$result = $conn->query($sql);
if ($result->num_rows > 0){
    echo "Login successfully";
}
else{
    echo "user not found";
}

$conn->close();
?>