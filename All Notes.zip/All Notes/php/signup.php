<?php
$servername = "localhost";
$user = "id17520058_shankar";
$pass = "Premshankar@123";
$dbname = "id17520058_student_data";
$firstname=$_POST["firstname"];
$lastname=$_POST["lastname"];
$username=$_POST["username"];
$email=$_POST["email"];
$mobile=$_POST["mobile"];
$password=$_POST["password"];

// Create connection
$conn = new mysqli($servername, $user, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO data(firstname, lastname,username,email,mobile, password)
VALUES ('$firstname', '$lastname', '$username','$email','$mobile','$password')";

if ($conn->query($sql) === TRUE) {
  echo "Data Inserted";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>